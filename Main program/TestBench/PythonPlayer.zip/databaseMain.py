import database
import os

database.addDirectory(database.cur, r"C:\Users\7kube\Music\reszta\mp3")
database.updateDatabase(database.cur)
print("Done")
